<?php
include '../encabezado.php';
?>
<html>
<body>
<div align="center"
	STYLE="background-color: cyan; width: 80%; position: absolute; top: 20%; left: 10%;">
<br>
<a href="list_user.php">Listado de Usuarios</a> <br>
<a href="list_user_type.php">Listado de Tipos de Usuarios</a><br>.</div>
</body>

</html>
