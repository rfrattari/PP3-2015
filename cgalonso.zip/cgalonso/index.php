<?php
header('location: app/principal.php');
?>